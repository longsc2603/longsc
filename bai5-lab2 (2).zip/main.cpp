/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <string>
#include <iostream>
using namespace std;
int main()
{
    int zip;
    string ten,dc,tp,nuoc;
    cout<<"Name: ";getline(std::cin,ten);
    cout<<"Address: ";getline(std::cin,dc);
    cout<<"Zip Code: ";cin>>zip;
    cin.ignore();
    cout<<"City: ";
    getline(std::cin,tp);
    cout<<"Country: ";
    getline(std::cin,nuoc);
    cout<<ten<<endl;
    cout<<dc<<endl;
    cout<<zip<<" "<<tp<<endl;
    cout<<nuoc;
    return 0;
}
