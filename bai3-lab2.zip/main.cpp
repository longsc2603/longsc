/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    float C,F;
    cout<<"Enter the temperature in Celsius : ";cin>>C;
    F=(9/5.0)*C+32;
    cout<<C<<" degrees Celsius = "<<F<<" degrees Fahrenheit.";
    return 0;
}
