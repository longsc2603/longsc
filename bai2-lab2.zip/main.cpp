/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    string x,y,z;
    float a,b,c,ave;
    cout<<"Enter the name of the 1st month: ";cin>>x;
    cout<<"Enter the rainfall for "<<x<<" : ";cin>>a;
    cout<<"Enter the name of the 2nd month: ";cin>>y;
    cout<<"Enter the rainfall for "<<y<<" : ";cin>>b;
    cout<<"Enter the name of the 3rd month: ";cin>>z;
    cout<<"Enter the rainfall for "<<z<<" : ";cin>>c;
    ave=(a+b+c)/3;
    cout<<"\nThe average rainfall for "<<x<<", "<<y<<", and "<<z<<" is "<<ave<<" inches.";
    
    

    return 0;
}
