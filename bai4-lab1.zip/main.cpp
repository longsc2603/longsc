/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std; 
int main()
{
   const int a = 28,b = 32,c = 37,d = 24,e = 33;
   int sum;
   float average;
   sum = a + b + c + d + e ;
   average = sum/5.0;
   cout <<"Average is "<<average;
    return 0;
}
