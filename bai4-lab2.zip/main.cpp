/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
    float m,h,bmi;
    cout<<"Enter your mass in kilograms : ";cin>>m;
    cout<<"Enter your height in meters : ";cin>>h;
    bmi=m*1.0/(h*h);
    cout<<"Your BMI is "<<fixed<<setprecision(2)<<bmi;
    return 0;
}
