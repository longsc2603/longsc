/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    cout<<"Danang is a very nice city."<<endl<<endl<<endl;
    cout<<"It is located in central Vietnam."<<endl<<endl<<endl;
    cout<<"A truly original dish of Danang is Mi Quang.";
    return 0;
}
